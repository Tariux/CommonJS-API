const XRouter = require("../callback/router")
const { EmployeModule } = require("../src/controller/employe")

const router = new XRouter()
router.post("/employeeService" , EmployeModule)
router.get("/employeeService" , EmployeModule)
router.put("/employeeService" , EmployeModule)
router.delete("/employeeService" , EmployeModule)    



module.exports = {
    router
}


