const { RedisConeection } = require("../database/redis");
const { _cr } = require("../helper/client-response");
const { XHelper } = require("../helper/functions");
const { router } = require("../routes/routes");
const url = require("url");

class XController {
  constructor() {
    this.redis = new RedisConeection();
    this.router = router;
    this.helper = new XHelper();
  }

  initContoller(request, response) {
    console.log(`Path ${request.url} Called`);

    try {
      this.body = this.parseBody(request);
    } catch (error) {
      return _cr(
        response,
        error.statusCode,
        "پارامتر های ورودی نامعتبر هستند!",
        error
      );
    }

    try {
      this.request = request;
      this.response = response;
      this.url = url.parse(this.request.url, true);

      if (this.isValidRequest()) {
        this.router.route(this.url.pathname, this.request, this.response , this.body);
      } else {
        return _cr(response, 500, "درخواست نامعتبر!", false);
      }
    } catch (error) {
      return _cr(
        response,
        error.statusCode || 500,
        "خطای ناشناخته رخ داد!",
        error
      );
    }
  }
  isValidRequest() {
    if (!this.request || !this.request.method) {
      return false;
    }
    return true;
  }

  parseBody(request) {
    return new Promise((resolve, reject) => {
      let body = "";
      let bodyChunks = [];
      let bodyChunksSize = 0;

      request.on("data", (chunk) => {
        bodyChunks.push(chunk);
        bodyChunksSize += chunk.byteLength;

        if (bodyChunksSize > 10 * 1024 * 1024) {
          console.error("Too large POST request.");
          resolve({});
        }
      });

      request.on("end", () => {
        let mergedBodyChunkBuffer = Buffer.concat(bodyChunks);
        body = mergedBodyChunkBuffer.toString("utf8");
        if (body.length > 0) {
          resolve(JSON.parse(body || "{}"));
        } else {
          resolve({});
        }
      });
    });
  }
}
module.exports = XController;
