
class EmployeModule {
  constructor(request, response) {
    super(request, response);
  }
  index() {
    this.getEmploye();
  }

  post() {
    this.updateEmploye();
  }

  update() {
    this.updateEmploye(false);
  }

  drop() {
    this.dropEmploye();
  }

  getEmploye() {
    if (!this.body.id) {
      throw('آیدی کاربر را وارد کنید!')
    }
    this.redis.safeQuery(async () => {
      try {
        let eid = this.body.id || false;
        let employe_key = `employe:${eid}`;
        let parent_key = `parent:${eid}`;

        this.redis.selectEmployeDB();
        let employeData = await this.redis.client.hGetAll(employe_key);
        this.redis.selectParentDB();
        let parentData = await this.redis.client.hGetAll(parent_key);

        let response = {
          ...employeData,
          parent_data:
            Object.keys(parentData).length > 0 ? parentData : false,
        }
      throw('عملیات با موفقیت انجام شد!' , response)

      } catch (error) {
        throw('خطایی در دریافت اطلاعات پیش آمد!' , error)

      }
    });
  }
  updateEmploye(isNew = true) {
    if (this.body.length <= 0) {
      return false;
    }
    this.redis.safeQuery(async () => {
      try {
        let employe_id;
        if (this.body.id && this.body.id !== "") {
          employe_id = this.body.id;
        } else {
          employe_id = await this.redis.employeUniqueID();
        }
        let parent_id = this.body.parent || false;
        let employe_key = `employe:${employe_id}`;
        let employe_parent_key = `employe:${parent_id}`;
        let parent_key = `parent:${employe_id}`;

        this.redis.selectEmployeDB();
        let parent_check = await this.redis.client.hGetAll(employe_parent_key);
        console.log(this.body);
        if (!parent_check || Object.keys(parent_check).length <= 0) {
          throw('کاربر مسئول پیدا نشد!!')
        }

        let employe_check = await this.redis.client.hGetAll(employe_key);
        if (
          isNew === false &&
          (!employe_check || Object.keys(employe_check).length <= 0)
        ) {
          throw('کاربر یافت نشد!')
        }

        this.redis.selectEmployeDB();
        let new_employe = {
          id: employe_id,
          data: JSON.stringify(this.body),
        }
        await this.redis.client.hSet(employe_key, new_employe);


        this.redis.selectParentDB();
        let new_parent = {
          id: parent_id,
          parent: employe_id,
        }
        await this.redis.client.hSet(parent_key, new_parent);

        
        throw('کاربر ایجاد شد!' , {
          "parent" : new_parent,
          "employe" : new_employe,
        })

      } catch (error) {
        throw('خطا در ایجاد کاربر!' , error)
      }
    });
  }
  dropEmploye() {
    if (!this.body.id) {
      throw('خطای اطلاعات ورودی!')
    }
    this.redis.safeQuery(async () => {
      try {
        let eid = this.body.id || false;
        let employe_key = `employe:${eid}`;
        let parent_key = `parent:${eid}`;

        this.redis.selectEmployeDB();
        let employeData = await this.redis.client.del(employe_key);
        this.redis.selectParentDB();
        let parentData = await this.redis.client.del(parent_key);

        if (parentData && employeData) {
          throw('حذف با موفقیت انجام شد!')

        } else {
          throw('حذف ناموفق بود!')
        }
      } catch (error) {
        throw(error)
      }
    });
  }
}
module.exports = {EmployeModule};
