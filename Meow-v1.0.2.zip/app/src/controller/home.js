const XController = require("../../callback/controller");

class HomeModule {
    constructor() {
    }
    index() {
        this.sendView('home');
    }
    post() {
    }
    drop() {

    }
    update() {

    }
    
    
}

module.exports = HomeModule