class XHelper {
  static findItemsByKeyValueInArray(items, key, value) {
    return items.filter((item) => item[key] === value);
  }
  static getUrlParameters(url) {
    var out = {};
    var str = url.search.replace("?", "");
    var subs = str.split(`&`).map((si) => {
      var keyVal = si.split(`=`);
      out[keyVal[0]] = keyVal[1];
    });
    return out;
  }
}

module.exports = { XHelper };
