function _cr(responseObj, statusCode, message, response) {
  let status = false;
  if (statusCode >= 200 && statusCode <= 300) {
    status = true;
  }

  const result = {
    status: status,
    statusCode: statusCode,
    message: message,
    response: response,
  };

  _lr(statusCode , message , response)
  responseObj.writeHead(statusCode, {
    "Content-Type": "application/json",
  });
  responseObj.end(JSON.stringify(result));



  return response
}



function _lr(statusCode, message, response) {
  let status = false;
  if (statusCode >= 200 && statusCode <= 300) {
    status = true;
  }

  const result = {
    status: status,
    statusCode: statusCode,
    message: message,
    response: response,
  };


  console.log(statusCode , result);


  return response
}



module.exports = {_cr , _lr};
