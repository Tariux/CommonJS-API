const { router } = require("../app/routes/routes");
const chai = require("chai");


// const { RedisConeection } = require("../app/database/redis");
// const { XLang } = require("../app/languages/lang");

// describe("XLang Class", function () {
//   describe("#__x()", function () {
//     it("this is for first test", function (done) {
//       const moduleXLang = new XLang();
//       let var1 = moduleXLang.__x();
//       chai.expect(var1).to.equal(true);
//       done();
//     });
//   });
// });

// describe("RedisDatabase Class", function () {
//   describe("#connection()", function () {
//     it("check connection for redis server", async function (done) {
//       const calledAsync = await new Promise(async (resolve, reject) => {
//         const redis = await new RedisConeection();
//         const connection = await redis.employeUniqueID();
//         resolve(true);
//         done();
//       });

//       console.log(calledAsync);
//       done();
//     });
//   });
// });

