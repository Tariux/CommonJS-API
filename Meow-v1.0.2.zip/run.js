const XCore = require('./app/core');
const instance = new XCore();
console.log('MEOW');
instance.init();