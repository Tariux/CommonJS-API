const XCore = require('./app/core');

const instance = new XCore();
instance.init(); // * this will load all the program and init!